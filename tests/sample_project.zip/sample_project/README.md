# Sample Project

This is a simple Python project that greets the user by name.

from utils import greet

def main():
    name = input("What's your name? ")
    greet(name)

if __name__ == "__main__":
    main()
